function toggleMobileMenu() {
  var mobileNav = document.getElementById('mobileNav');
  mobileNav.classList.toggle('open');
}

function toggleFaq(element) {
  var faqItem = element.parentElement;
  var allFaqItems = document.querySelectorAll('.faq-item');
  
  allFaqItems.forEach(function(item) {
    if (item !== faqItem) {
      item.classList.remove('open');
    }
  });
  
  faqItem.classList.toggle('open');
}

document.addEventListener('click', function(event) {
  var mobileNav = document.getElementById('mobileNav');
  var menuBtn = document.querySelector('.mobile-menu-btn');
  
  if (mobileNav && mobileNav.classList.contains('open')) {
    if (!mobileNav.contains(event.target) && !menuBtn.contains(event.target)) {
      mobileNav.classList.remove('open');
    }
  }
});

document.addEventListener('DOMContentLoaded', function() {
  var header = document.querySelector('header');
  
  window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
      header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    } else {
      header.style.boxShadow = 'none';
    }
  });
  
  updateLiveLessonCard();
  setInterval(updateLiveLessonCard, 60000);
});

var schedule = {
  0: [],
  1: [
    { time: '18:00 - 20:00', subjects: 'Maths & Business Studies' },
    { time: '20:00 - 22:00', subjects: 'Accounting & Life Sciences' }
  ],
  2: [
    { time: '18:00 - 20:00', subjects: 'Accounting & Geography' },
    { time: '20:00 - 22:00', subjects: 'Math Literacy & Physical Sciences' },
    { time: '22:00 - 23:00', subjects: 'Economics' }
  ],
  3: [
    { time: '18:00 - 20:00', subjects: 'Economics & Physical Sciences' },
    { time: '20:00 - 22:00', subjects: 'Geography & Mathematics' }
  ],
  4: [
    { time: '18:00 - 20:00', subjects: 'Life Sciences & Business Studies' },
    { time: '20:00 - 22:00', subjects: 'Math Literacy & Accounting' }
  ],
  5: [
    { time: '18:00 - 20:00', subjects: 'Physical Sciences & Mathematics' },
    { time: '20:00 - 22:00', subjects: 'Economics & Geography' }
  ],
  6: [
    { time: '09:00 - 12:00', subjects: 'Revision Sessions' },
    { time: '14:00 - 17:00', subjects: 'Exam Prep' }
  ]
};

var dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function updateLiveLessonCard() {
  var heroCard = document.querySelector('.hero-card');
  if (!heroCard) return;
  
  var now = new Date();
  var currentDay = now.getDay();
  var currentHour = now.getHours();
  var currentMinute = now.getMinutes();
  
  var timeString = now.toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' });
  var dateString = now.toLocaleDateString('en-ZA', { day: 'numeric', month: 'long', year: 'numeric' });
  var dayString = dayNames[currentDay];
  
  var headerLabel = heroCard.querySelector('.hero-card-label');
  var headerTitle = heroCard.querySelector('.hero-card-title');
  
  if (headerLabel) {
    headerLabel.innerHTML = '<span style="display: block; font-size: 1.1rem; color: white; font-weight: 600;">' + timeString + '</span>' +
                           '<span style="display: block; margin-top: 2px;">' + dayString + ', ' + dateString + '</span>';
  }
  
  var nextLesson = findNextLesson(currentDay, currentHour, currentMinute);
  
  if (headerTitle) {
    if (nextLesson) {
      headerTitle.textContent = 'Next: ' + nextLesson.subjects.split(' & ')[0];
    } else {
      headerTitle.textContent = 'Check Schedule';
    }
  }
  
  var lessonItems = heroCard.querySelectorAll('.lesson-item');
  var upcomingLessons = getUpcomingLessons(currentDay, currentHour, currentMinute);
  
  lessonItems.forEach(function(item, index) {
    if (upcomingLessons[index]) {
      var lesson = upcomingLessons[index];
      var icon = item.querySelector('.lesson-icon');
      var info = item.querySelector('.lesson-info');
      
      if (icon) {
        icon.textContent = lesson.subjects.charAt(0);
      }
      if (info) {
        var h4 = info.querySelector('h4');
        var p = info.querySelector('p');
        if (h4) h4.textContent = lesson.subjects;
        if (p) p.textContent = lesson.day + ', ' + lesson.time;
      }
    }
  });
}

function findNextLesson(currentDay, currentHour, currentMinute) {
  var currentTime = currentHour * 60 + currentMinute;
  
  var todayLessons = schedule[currentDay] || [];
  for (var i = 0; i < todayLessons.length; i++) {
    var lessonStartHour = parseInt(todayLessons[i].time.split(':')[0]);
    var lessonStartTime = lessonStartHour * 60;
    if (currentTime < lessonStartTime) {
      return todayLessons[i];
    }
  }
  
  for (var d = 1; d <= 7; d++) {
    var nextDay = (currentDay + d) % 7;
    var nextDayLessons = schedule[nextDay] || [];
    if (nextDayLessons.length > 0) {
      return nextDayLessons[0];
    }
  }
  
  return null;
}

function getUpcomingLessons(currentDay, currentHour, currentMinute) {
  var upcoming = [];
  var currentTime = currentHour * 60 + currentMinute;
  
  var todayLessons = schedule[currentDay] || [];
  for (var i = 0; i < todayLessons.length; i++) {
    var lessonStartHour = parseInt(todayLessons[i].time.split(':')[0]);
    var lessonStartTime = lessonStartHour * 60;
    if (currentTime < lessonStartTime) {
      upcoming.push({
        day: dayNames[currentDay],
        time: todayLessons[i].time,
        subjects: todayLessons[i].subjects
      });
    }
  }
  
  for (var d = 1; d <= 7 && upcoming.length < 2; d++) {
    var nextDay = (currentDay + d) % 7;
    var nextDayLessons = schedule[nextDay] || [];
    for (var j = 0; j < nextDayLessons.length && upcoming.length < 2; j++) {
      upcoming.push({
        day: dayNames[nextDay],
        time: nextDayLessons[j].time,
        subjects: nextDayLessons[j].subjects
      });
    }
  }
  
  return upcoming;
}

function handleLogin(event) {
  event.preventDefault();
  
  var emailPhone = document.getElementById('emailPhone').value;
  var password = document.getElementById('password').value;
  var rememberMe = document.getElementById('rememberMe').checked;
  
  if (emailPhone && password) {
    if (rememberMe) {
      localStorage.setItem('rememberedUser', emailPhone);
    } else {
      localStorage.removeItem('rememberedUser');
    }
    
    sessionStorage.setItem('isLoggedIn', 'true');
    sessionStorage.setItem('userEmail', emailPhone);
    
    window.location.href = 'dashboard.html';
  } else {
    alert('Please enter both email/phone and password.');
  }
}

function handleLogout() {
  sessionStorage.removeItem('isLoggedIn');
  sessionStorage.removeItem('userEmail');
  window.location.href = 'index.html';
}

document.addEventListener('DOMContentLoaded', function() {
  var emailPhoneInput = document.getElementById('emailPhone');
  if (emailPhoneInput) {
    var rememberedUser = localStorage.getItem('rememberedUser');
    if (rememberedUser) {
      emailPhoneInput.value = rememberedUser;
      var rememberMeCheckbox = document.getElementById('rememberMe');
      if (rememberMeCheckbox) {
        rememberMeCheckbox.checked = true;
      }
    }
  }
});
